package Proiect.demo.Controller;


import Proiect.demo.Dao.User;
import Proiect.demo.Exception.UserException;
import Proiect.demo.Security.UserSession;
import Proiect.demo.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class LoginController {


    @Autowired
    UserService userService;

    @Autowired
    UserSession userSession;



    @GetMapping("/register")
    public ModelAndView register(){
        return new ModelAndView("register");
    }


    @GetMapping("/register-form")
    public ModelAndView registerForm( @RequestParam("email") String email,
                                      @RequestParam("password1") String password1,
                                      @RequestParam("password2") String password2,
                                      @RequestParam("numarTelefon") String numarTelefon,
                                      @RequestParam("adresa") String adresa) throws UserException {
        ModelAndView modelAndView = new ModelAndView("register");

        List<User> userList = userService.getUsersByEmail(email);
        if (!password1.equals(password2)) {
            modelAndView.addObject("message", "parolele nu sunt egale");
            return modelAndView;
        } else {
            //daca sunt corecte, ce fac mai departe?
            userService.save(email, password1, numarTelefon, adresa);
        }

        if (userList.size() > 0) {
            //daca utilizatorul exista deja in tabela users?
            modelAndView.addObject("message", "Acest email este deja folosit");
            return modelAndView;
        } else {
            //daca nu exista -> login
            modelAndView = new ModelAndView("redirect:/login");
        }

        return modelAndView;

    }


    @GetMapping("/login")
    public ModelAndView login(){
        return new ModelAndView("login");
    }


    @GetMapping("/submitLogin")
    public ModelAndView login(@RequestParam("email")String email,
                              @RequestParam("password")String password){
        ModelAndView modelAndView = new ModelAndView("login");

        List<User> userList = userService.getUsersByEmail(email);
        if (userList.size() == 0) {
            modelAndView.addObject("message", "Userul nu exista");
        }
        if (userList.size() > 1) {
            modelAndView.addObject("message", "User existent");
        }
        if (userList.size() == 1) {
            User userDB = userList.get(0);
            if (!userDB.getPassword().equals(password)) {
                modelAndView.addObject("message", "Parola incorecta");
                return modelAndView;
            } else {
                userSession.setId(userDB.getId());
            }
        }
        return new ModelAndView("redirect:index.html");

    }


}
