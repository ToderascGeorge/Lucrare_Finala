package Proiect.demo.Controller;

import Proiect.demo.Service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AdminController {

    @Autowired
    ProductService productService;


    @GetMapping("/addProducts")
    public ModelAndView getProductsPage() {
        ModelAndView modelAndView = new ModelAndView("addProducts");
        return modelAndView;
    }

    //aici trebuie sa iti faci o metoda prin care sa inserezi in bd informatiile din request ale produsului
    @PostMapping("/saveProdus")
    public ModelAndView saveProdus(@RequestParam("name") String name,
                                   @RequestParam("durata") Integer durata,
                                   @RequestParam("efecte") String efecte,
                                   @RequestParam("pret") Integer pret) {
        ModelAndView modelAndView = new ModelAndView("addProducts");

        productService.addProduct(name,durata,efecte,pret);

        return modelAndView;
    }


}
