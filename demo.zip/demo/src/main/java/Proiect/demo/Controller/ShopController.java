package Proiect.demo.Controller;

import Proiect.demo.Dao.*;
import Proiect.demo.Security.UserSession;
import Proiect.demo.Service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


@Controller
public class ShopController {

    @Autowired
    UserSession userSession;
    @Autowired
    ProductService productService;

    @Autowired
    OrderDao orderDao;

    List<Product> productList;

    @GetMapping("/contact")
    public ModelAndView contact(){
        ModelAndView modelAndView = new ModelAndView("contact");
        return modelAndView;
    }

    @GetMapping("/about")
    public ModelAndView about(){
        ModelAndView modelAndView = new ModelAndView("about");
        return modelAndView;
    }
    @GetMapping("/dashboard")
    public ModelAndView cancel(){
        ModelAndView modelAndView = new ModelAndView("dashboard");


        return modelAndView;
    }
    @GetMapping("/showProducts")
    public ModelAndView produse(){
        ModelAndView modelAndView = new ModelAndView("produse");
        return modelAndView;
    }

    @GetMapping("/viewProduse")
    public ModelAndView viewProducts(){
        ModelAndView modelAndView = new ModelAndView("produse");
        List<Product> productList = productService.getAllProducts();
        modelAndView.addObject("products", productList);

        return modelAndView;
    }

    @PostMapping("/addToCart")
    public ModelAndView addToCart(@RequestParam("productId") Integer id) {
        ModelAndView modelAndView = new ModelAndView("produse");
        int itemsCart = 0;
        modelAndView.addObject("products", productList);

        userSession.addToCart(id);
        for (int quantity : userSession.getShoppingCart().values()) {
            itemsCart += quantity;
        }
        modelAndView.addObject("items", itemsCart);
        return new ModelAndView("redirect:/viewProduse");
    }


    @PostMapping("/showCart")
    public ModelAndView showCart() {
        ModelAndView modelAndView = new ModelAndView("cos");
        List<CartItems> cartItems = new ArrayList<>();
        for (Map.Entry<Integer,Integer> entry:userSession.getShoppingCart().entrySet()) {
            int productId = entry.getKey();
            int quantity = entry.getValue();
            Product product = productService.findById(productId);
            CartItems cartItem = new CartItems();
            cartItem.setId(productId);
            cartItem.setName(product.getName());
            cartItem.setPret(product.getPret());
            cartItem.setCartSum(quantity * product.getPret());

            cartItems.add(cartItem);


        }
        modelAndView.addObject("cartList", cartItems);
        return modelAndView;
    }


    @GetMapping("/buyCart")
    public ModelAndView modelAndView() {
        ModelAndView modelAndView = new ModelAndView("order");

        List<OrderLines> orderLines = new ArrayList<>();
        for (Map.Entry<Integer, Integer> entry : userSession.getShoppingCart().entrySet()) {
            int productId = entry.getKey();
            int quantity = entry.getValue();
            Product product = productService.findById(productId);

            OrderLines orderLines1 = new OrderLines();
            orderLines1.setProductId(productId);
            orderLines1.setQuantity(quantity);
            orderLines1.setPrice(product.getPret() * quantity);
            orderLines.add(orderLines1);
        }
        Order order = new Order();
        order.setUserId(userSession.getId());
        order.setOrderLines(orderLines);
        orderDao.save(order);
        userSession.getShoppingCart().clear();
        return modelAndView;
    }

}
