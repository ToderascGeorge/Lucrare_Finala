package Proiect.demo.Dao;

public class CartItems extends Product{

    private double cartSum ;

    public double getCartSum() {
        return cartSum;
    }

    public void setCartSum(double cartSum) {
        this.cartSum = cartSum;
    }
}
