package Proiect.demo.Service;


import Proiect.demo.Dao.Product;
import Proiect.demo.Dao.ProductDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {


    @Autowired
    ProductDao productDao;

    public List<Product> getAllProducts(){
        return (List<Product>) productDao.findAll();
    }

    public String addProduct(String name, Integer durata, String efecte, Integer pret ){

        Product product = new Product();
        product.setName(name);
        product.setDurata(durata);
        product.setEfecte(efecte);
        product.setPret(pret);
        productDao.save(product);

        return "Produsul " + product.getName() + " a fost salvat cu succes";

    }


    public String removeProduct(Integer id){
        productDao.deleteById(id);
        return "produsul a fost sters";


    }

    public Product findById(int id){
        return productDao.findById(id).get();

    }
}
