package Proiect.demo.Service;

import Proiect.demo.Dao.User;
import Proiect.demo.Dao.UserDao;
import Proiect.demo.Exception.UserException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    @Autowired
    UserDao userDao;

    public void save(String email, String password, String numarTelefon, String adresa){
        User user = new User();
        user.setEmail(email);
        user.setPassword(password);
        user.setNumarTelefon(numarTelefon);

        userDao.save(user);
    }

    public void checkPassword( String password1, String password2 ) throws UserException {
        if (!password1.equals(password2)){
            throw new UserException("parolele nu sunt egale din exceptie");
        }
    }

    public List<User> getUsersByEmail(String email){
        return userDao.findByEmail(email);
    }
}
