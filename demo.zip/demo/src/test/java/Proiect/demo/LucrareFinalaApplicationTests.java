package Proiect.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LucrareFinalaApplicationTests {

	@Test
	void contextLoads() {
	}

}
